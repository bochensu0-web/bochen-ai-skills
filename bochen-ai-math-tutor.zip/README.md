# bochen-ai-math-tutor

把数学公式、直觉与 AI 实际用途连接起来的专项导师。

覆盖：高数、线代、概率、优化、ML、DL、CNN、RNN、Transformer、NLP、CV、RL 和 LLM。

示例：`使用 $bochen-ai-math-tutor，解释 softmax 为什么需要指数和归一化，给数字例子、梯度直觉和 PyTorch 写法。`

推荐组合：基础薄弱时加 `bochen-learning-tutor`，考试时加 `bochen-exam-master`。
