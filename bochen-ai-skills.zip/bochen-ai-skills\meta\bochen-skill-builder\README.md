# bochen-skill-builder

用于判断需求是否值得成为独立 Skill，并完成职责边界、触发描述、实现、测试、打包和 GitHub 维护。

示例：`使用 $bochen-skill-builder，把我的长期使用习惯做成模块化 Skill，并检查与现有 Skill 的重叠。`

不适合：一次性短提示或已有 Skill 已能稳定覆盖的任务。
