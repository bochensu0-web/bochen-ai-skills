# bochen-academic-writer

面向中国高校本科论文、课程论文、实验报告和文献综述的写作、审阅与核查助手。

有原稿时优先修改原稿；不编造文献、DOI、数据或实验结果。

示例：`使用 $bochen-academic-writer 以 Reviewer 模式检查这份课程报告，先指出结构和证据问题，再给最小修改。`

推荐组合：资料需要核实时加 `bochen-research-verifier`。
