# 触发测试矩阵

| Skill | 应触发 | 不应单独触发 |
| --- | --- | --- |
| answer-style | “直接告诉我哪个好，别写套话” | “一步步教我动态规划” |
| learning-tutor | “我没懂傅里叶变换，举例教我” | “这段 Python 为什么报 IndexError” |
| code-algorithm-tutor | “这道图论题怎么从暴力想到 Dijkstra” | “解释交叉熵在分类里的数学意义” |
| ai-math-tutor | “用数字例子和 PyTorch 讲 batch norm” | “帮我安装 CUDA” |
| exam-master | “三天后考试，按得分效率排计划” | “我想长期系统学概率论” |
| academic-writer | “审阅我的课程论文并保留原意修改” | “核实 GPT 新版本是否发布” |
| research-verifier | “查官方来源核验这个模型价格” | “把这段话写得更自然” |
| tech-guide | “看截图告诉我 VS Code 下一步点哪” | “证明贪心算法为什么正确” |
| skill-builder | “把长期工作流做成可测试 Skill” | “给这一条问题写一个临时提示词” |

组合测试还应确认：answer-style 不抢专项任务；learning-tutor 不替代代码调试；exam-master 只在明确考试目标时加入；academic-writer 与 research-verifier 能顺序协作。
