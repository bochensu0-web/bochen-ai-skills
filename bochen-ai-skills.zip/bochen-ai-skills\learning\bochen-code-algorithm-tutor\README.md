# bochen-code-algorithm-tutor

面向 C++、Python、数据结构、算法、LeetCode 和 Debug 的专项导师，重点解释算法怎样想到。

适合：从暴力到优化、手推样例、C++ 实现、复杂度、边界和同类题迁移。

不适合：纯 AI 数学推导、一般软件安装。

示例：`使用 $bochen-code-algorithm-tutor，从暴力方法开始讲这道动态规划题，说明优化线索并给适合考试手写的 C++。`

推荐组合：学习时加 `bochen-learning-tutor`，备考时加 `bochen-exam-master`。
